import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import linregress

def draw_plot():
  # Read data from file
  df = pd.read_csv('epa-sea-level.csv')


  # Create scatter plot
  fig , axes = plt.subplots(1, figsize =(20, 10))
  plt.scatter(df['Year'], df['CSIRO Adjusted Sea Level'], c= 'c')
  
  # Create first line of best fit
  a = linregress(x=df['Year'], y = df['CSIRO Adjusted Sea Level'])
  x=df['Year'].astype(int).values.tolist()
  for i in range(x[-1]+1,2051):
    x.append(i)
  y = [ b * a.slope + a.intercept for b in x]
  plt.plot(x, y, c='r')


  # Create second line of best fit
  x1=df[df['Year']>=2000]['Year'].astype(int).values.tolist()
  x2=df[df['Year']>=2000]['CSIRO Adjusted Sea Level'].astype(float).values.tolist()
  a1 = linregress(x=x1, y = x2)
  for i in range(x1[-1]+1,2051):
    x1.append(i)
  y1 = [ b * a1.slope + a1.intercept for b in x1]
  plt.plot(x1, y1, c='m')

  # Add labels and title
  font = {'family': 'serif',
        'color':  'darkred',
        'weight': 'bold',
        'size': 18,
        }
  plt.xlabel('Year', fontweight ='bold', fontsize = 15)
  plt.ylabel('Sea Level (inches)', fontweight ='bold', fontsize = 15)
  axes.set_title('Rise in Sea Level' , fontdict = font )
    
  # Save plot and return data for testing (DO NOT MODIFY)
  plt.savefig('sea_level_plot.png')
  return plt.gca()